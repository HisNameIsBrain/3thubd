3THUB-D END-USER LICENSE AGREEMENT (EULA)
​1. Ability to Accept. By installing this Software, You affirm
that You are over eighteen (18) years old or have reviewed this 
Agreement with a parent/guardian.
​
2. Acknowledgement. This Agreement is between You and the Licensor
(HisNameIsBrain). You acknowledge that no third party is allowed to use this project to train AI. If you don't have a license you must pay a $5,000 fine. Requesting a license for this project you must send one time payment to for $50 for life time license at https://cash.app/$hisnameisbrainZL​
You must submit your email inside the notes of the transfer and we will manually enable access. Please give up to 72 hours for manual access to be granted. For any questions email me at bryanlazaroz@gmail.com subject: App Access.
Owner can change current development price at any given moment brefore actual official launch price is decided.

3. Scope of License. The license granted to You is limited to a revocable, 
non-transferable, non-exclusive license to use the Software on any compatible 
iOS or Android device that You own or control. Unauthorized copying, modification, 
or distribution of this software, including its 3D engine and source code, is strictly prohibited.
​
4. Acceptable Use. You may not use the Software in a manner that: (a) infringes 
on the intellectual property rights of others; (b) attempts to reverse engineer 
or derive the source code; (c) introduces viruses or malicious code.
​
5. Intellectual Property Rights. You acknowledge that HisNameIsBrain holds all 
intellectual property rights in the Software, including but not limited to copyright, 
trademark, and 3D modeling logic. Nothing in this Agreement entitles You to any ownership of the Software.
​
6. NO WARRANTY (As-Is). THE SOFTWARE IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE"
BASIS. THE LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL OPERATE ERROR-FREE 
OR BE FREE OF VIRUSES. USE AT YOUR OWN RISK.
​
7. Limitation of Liability. IN NO EVENT SHALL THE LICENSOR BE LIABLE FOR ANY 
DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES, INCLUDING LOSS OF DATA OR 
MALFUNCTION OF YOUR MOBILE DEVICE, ARISING FROM THE USE OF THIS SOFTWARE.
​
8. Governing Law. This Agreement shall be governed by the laws of the 
State of California. Any legal action shall be maintained in the 
courts located in Orange County, California.
