3THUB-D
Copyright (c) 2026 HisNameIsBrain.
All Rights Reserved.

This software is proprietary and confidential.
It is licensed, sold, under the 3THUB-D End-User License Agreement (EULA).

No portion of this software may be copied, modified, distributed,
reverse engineered, decompiled, or otherwise used except as expressly
permitted under the EULA.

All other trademarks and registered trademarks are the property
of their respective owners.
